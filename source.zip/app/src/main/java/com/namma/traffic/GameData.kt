package com.namma.traffic

// ---- tiny builders to keep the map readable ----

private fun ev(
    chance: Double,
    line: String,
    dt: Int = 0,
    dh: Int = 0,
    only: Vehicle? = null,
    fatal: Boolean = false
) = GameEvent(chance, line, dt, dh, only, fatal)

private fun c(
    label: String,
    road: String,
    to: String,
    ct: Int,
    ch: Int,
    bt: Int,
    bh: Int,
    events: List<GameEvent> = emptyList()
) = Choice(label, road, to, ct, ch, bt, bh, events)

private fun j(
    id: String,
    name: String,
    blurb: String,
    vararg choices: Choice
) = Junction(id, name, blurb, choices.toList())

// =====================================================================
// SCENARIO 1 — Electronic City -> Kempegowda International Airport
// =====================================================================

private val s1List: List<Junction> = listOf(
    j("ecity", "Electronic City",
        "42 km of pure Bangalore stands between you and your boarding gate. The clock is already judging you.",
        c("Hit the Elevated Expressway", "Hosur Road Flyover", "toll", 5, 1, 3, 3,
            listOf(ev(0.30, "Toll booth ahead. Six lanes funnel into the one that's open.", dt = 4, only = Vehicle.CAR))),
        c("Sneak through the service road", "E-City Service Road", "bomma", 7, 2, 4, 4,
            listOf(ev(0.35, "The service road is 70% pothole. Your spine files a complaint.", dh = 8, only = Vehicle.BIKE)))
    ),
    j("toll", "E-City Toll Plaza",
        "The FASTag reader blinks, thinks about it, and rejects you on principle.",
        c("Pay up and roll", "Hosur Road", "hosur", 4, 1, 3, 2),
        c("Squeeze through the two-wheeler gap", "Toll Bypass", "hosur", 3, 1, 2, 3,
            listOf(ev(0.25, "You clipped the divider threading the gap.", dh = 6, only = Vehicle.BIKE)))
    ),
    j("hosur", "Hosur Road Elevated Expressway",
        "Smooth, glorious, six lanes of hope suspended above the chaos. It cannot last.",
        c("Cruise the flyover", "Elevated Expressway", "bomma", 4, 1, 3, 2,
            listOf(ev(0.25, "A biker cut in front of a truck. Everyone brakes for no reason.", dt = 5, only = Vehicle.CAR))),
        c("Exit early to dodge the ramp jam", "Bommanahalli Exit", "bomma", 6, 1, 3, 3)
    ),
    j("bomma", "Bommanahalli",
        "The flyover ends and politely dumps forty thousand vehicles into a single blinking signal.",
        c("Push toward Silk Board", "Hosur Road", "silkboard", 6, 2, 3, 3,
            listOf(ev(0.40, "The signal turned red the exact moment you reached it. Naturally.", dt = 6, only = Vehicle.CAR))),
        c("Cut through Madiwala", "Madiwala Market", "madiwala", 8, 2, 4, 4,
            listOf(ev(0.30, "A man is selling mangoes in the middle of the road. Business is booming.", dt = 4)))
    ),
    j("madiwala", "Madiwala",
        "Somehow a market, a bus stand, and a lake at once, all three refusing to let you pass.",
        c("Rejoin the main road", "Tank Bund Road", "silkboard", 5, 1, 3, 3),
        c("Take the BTM cut", "16th Main", "btm", 6, 2, 4, 3)
    ),
    j("silkboard", "CENTRAL SILK BOARD",
        "The final boss of Bangalore traffic. Abandon hope, all ye who indicate here.",
        c("Brave the ORR ramp (HSR side)", "Outer Ring Road", "hsr", 7, 2, 4, 4,
            listOf(
                ev(0.55, "Silk Board flyover jam. You have aged a full year.", dt = 12, only = Vehicle.CAR),
                ev(0.15, "A bus and an auto are locked in a philosophical standoff.", dt = 6)
            )),
        c("Escape toward BTM", "BTM Layout", "btm", 6, 2, 4, 3,
            listOf(ev(0.40, "Silk Board underpass. Underwater in spirit, if not yet in fact.", dt = 8, only = Vehicle.CAR))),
        c("U-turn — this was a mistake", "back to Hosur Road", "hosur", 4, 2, 3, 3)
    ),
    j("hsr", "HSR Layout",
        "Planned, leafy, sector-numbered, and still somehow completely gridlocked.",
        c("Head to Agara junction", "Outer Ring Road", "agara", 5, 1, 3, 3),
        c("Gamble on Sarjapur Road", "Sarjapur Road", "sarjapur", 6, 2, 3, 4,
            listOf(ev(0.30, "Tech park shift change. Forty thousand people had your exact idea.", dt = 5)))
    ),
    j("agara", "Agara Junction",
        "The lake is serene. The traffic is the opposite of serene.",
        c("Push to Bellandur", "Outer Ring Road", "bellandur", 6, 2, 3, 3),
        c("Slip through Iblur underpass", "Iblur", "iblur", 5, 1, 3, 3,
            listOf(ev(0.30, "Iblur merge. Three lanes negotiating for the space of one.", dt = 5, only = Vehicle.CAR)))
    ),
    j("sarjapur", "Sarjapur Road",
        "Every third building is a tech park and every road is permanently 'under development'.",
        c("Cut back to ORR at Bellandur", "Bellandur", "bellandur", 6, 2, 4, 4,
            listOf(ev(0.35, "The road is 60% crater. Your kidneys have relocated.", dh = 10, only = Vehicle.BIKE))),
        c("Detour via Carmelaram", "Carmelaram", "carmelaram", 7, 2, 4, 3)
    ),
    j("carmelaram", "Carmelaram",
        "You are now genuinely lost. Even the map app looks nervous.",
        c("Find your way back to ORR", "Bellandur", "bellandur", 8, 2, 5, 4,
            listOf(ev(0.20, "Railway crossing. Gate shut for a train that shows no sign of existing.", dt = 6)))
    ),
    j("iblur", "Iblur Junction",
        "The flyover giveth, and the merge immediately taketh away.",
        c("Merge onto ORR", "Outer Ring Road", "bellandur", 5, 1, 3, 3)
    ),
    j("bellandur", "Bellandur",
        "The lake is frothing. If it rained in the last week, may whatever you believe in help you.",
        c("Power through to Marathahalli", "Outer Ring Road", "marathahalli", 6, 2, 4, 4,
            listOf(
                ev(0.30, "Waterlogging. Your vehicle is now, technically, a boat.", dt = 8, dh = 3),
                ev(0.07, "The road vanished under brown water. A passing tempo rescued you, but not your plans.", fatal = true)
            )),
        c("Try the Kadubeesanahalli inner road", "Kadubeesanahalli", "kadu", 7, 2, 4, 3)
    ),
    j("kadu", "Kadubeesanahalli",
        "Four tech parks, one lane, zero mercy. Every cab in the state is dropping someone off. Right now. Ahead of you.",
        c("Crawl back to ORR", "Outer Ring Road", "marathahalli", 7, 2, 4, 4,
            listOf(ev(0.40, "Drop-off chaos: twelve Innovas, one available square metre.", dt = 7, only = Vehicle.CAR)))
    ),
    j("marathahalli", "Marathahalli Bridge",
        "The halfway point — if you still believe in yourself, which by now you don't.",
        c("Take ORR north to K R Puram", "Outer Ring Road", "krpuram", 6, 2, 3, 3,
            listOf(ev(0.40, "ORR northbound: a parking lot that occasionally, teasingly, moves.", dt = 8, only = Vehicle.CAR))),
        c("Old Airport Road via a 'shortcut'", "Whitefield-side inner road", "byappanahalli", 6, 2, 4, 3)
    ),
    j("btm", "BTM Layout",
        "A labyrinth of one-ways designed by someone who hated you personally.",
        c("Head to Koramangala", "100 Feet Road", "koramangala", 5, 2, 3, 3),
        c("Loop over the Jayadeva flyover", "Jayadeva", "jayadeva", 6, 2, 4, 3,
            listOf(ev(0.35, "Jayadeva flyover: three levels of interchange, all of them stationary.", dt = 6, only = Vehicle.CAR)))
    ),
    j("jayadeva", "Jayadeva Flyover",
        "A three-level interchange that looks like a plate of noodles from above and feels like one from inside.",
        c("Escape toward Koramangala", "Inner Ring Road", "koramangala", 6, 2, 4, 3)
    ),
    j("koramangala", "Koramangala",
        "Cafes, startups, and a road grid that predates the concept of the automobile.",
        c("Sony World signal to Indiranagar", "Inner Ring Road", "indiranagar", 6, 2, 3, 3,
            listOf(ev(0.35, "Sony World junction. The signal is a suggestion that everyone declines.", dt = 6, only = Vehicle.CAR))),
        c("Ejipura shortcut", "Ejipura", "ejipura", 7, 2, 4, 4,
            listOf(ev(0.40, "Ejipura road. Officially a road. Practically a riverbed with ambitions.", dh = 9, only = Vehicle.BIKE)))
    ),
    j("ejipura", "Ejipura",
        "Under construction since roughly the dawn of time. The construction has outlived several governments.",
        c("Struggle on to Indiranagar", "Viaduct Road", "indiranagar", 7, 2, 5, 4)
    ),
    j("indiranagar", "Indiranagar 100 Feet Road",
        "Trendy, expensive, and moving at the exact speed of regret.",
        c("Old Airport Road toward Domlur", "Old Airport Road", "domlur", 6, 2, 3, 3,
            listOf(ev(0.30, "Metro works. The road narrows to the width of a good intention.", dt = 5))),
        c("CMH Road to the Metro pillars", "CMH Road", "domlur", 6, 2, 4, 3)
    ),
    j("domlur", "Domlur",
        "Flyover above, chaos below, and a signal that has personally wronged you.",
        c("Old Airport Road to Marathahalli", "Old Airport Road", "marathahalli", 7, 2, 4, 3),
        c("Signal-free route from a WhatsApp forward", "Byappanahalli", "byappanahalli", 6, 2, 4, 3)
    ),
    j("byappanahalli", "Byappanahalli",
        "You trusted a WhatsApp forward's directions. This was, in hindsight, your first mistake.",
        c("Find the main road again", "Old Madras Road", "krpuram", 7, 2, 4, 4,
            listOf(ev(0.20, "Old Madras Road. New Madras-level traffic.", dt = 6)))
    ),
    j("krpuram", "K R Puram Hanging Bridge",
        "Four roads, one bridge, and infinite patience required — of which you have none left.",
        c("Tin Factory toward Hebbal", "Outer Ring Road", "tinfactory", 6, 2, 3, 3,
            listOf(ev(0.45, "Tin Factory. The name is industrial; the vibe is pure despair.", dt = 9, only = Vehicle.CAR))),
        c("Old Madras Road city route", "Old Madras Road", "ulsoor", 7, 2, 4, 3)
    ),
    j("ulsoor", "Ulsoor",
        "Pretty lake. Ugly traffic. You are, sadly, not here for the lake.",
        c("Cut to the ring road north", "Bund Road", "tinfactory", 7, 2, 4, 3)
    ),
    j("tinfactory", "Tin Factory",
        "A junction so congested it has developed its own gravitational field.",
        c("Push toward Hebbal", "Outer Ring Road", "hebbal", 6, 2, 3, 3,
            listOf(ev(0.40, "ORR to Hebbal: bumper to bumper to bumper to horizon.", dt = 8, only = Vehicle.CAR))),
        c("Duck into Banaswadi", "Banaswadi", "banaswadi", 7, 2, 4, 3)
    ),
    j("banaswadi", "Banaswadi",
        "A residential maze. Somewhere in here is a road out. Somewhere.",
        c("Escape toward Hebbal", "Outer Ring Road", "hebbal", 7, 2, 4, 4)
    ),
    j("hebbal", "Hebbal Flyover",
        "The gateway to the airport road. You can almost smell the jet fuel. Almost.",
        c("Onto Ballari Road (NH 44)", "Ballari Road", "ballari", 5, 2, 3, 3,
            listOf(ev(0.50, "Hebbal flyover jam. Built to fix traffic, it has itself become traffic.", dt = 10, only = Vehicle.CAR))),
        c("Loop out via Mekhri Circle", "Mekhri Circle", "mekhri", 6, 2, 4, 3)
    ),
    j("mekhri", "Mekhri Circle",
        "You took the scenic route. It is not scenic. It is merely longer.",
        c("Rejoin Ballari Road", "Ballari Road", "ballari", 7, 2, 4, 3)
    ),
    j("ballari", "Ballari Road (NH 44)",
        "Open highway at last. Nothing can stop you now. (Something is about to stop you now.)",
        c("Floor it to Yelahanka", "NH 44", "yelahanka", 5, 1, 3, 3,
            listOf(
                ev(0.20, "Toll plaza. FASTag not recognised. Existential negotiations ensue.", dt = 6),
                ev(0.15, "Trucks. An entire nation's supply of trucks, all in your lane.", dt = 8, only = Vehicle.CAR)
            )),
        c("Take the airport expressway", "Airport Trumpet", "trumpet", 4, 1, 3, 3)
    ),
    j("yelahanka", "Yelahanka",
        "Almost clear of the city's gravity. The airport is a rumour beginning to feel real.",
        c("Final stretch to the airport", "NH 44", "trumpet", 5, 1, 3, 3,
            listOf(ev(0.30, "Highway speed plus a surprise pothole. Your wrists will remember this forever.", dh = 8, only = Vehicle.BIKE)))
    ),
    j("trumpet", "Trumpet Interchange",
        "The final flyover. The terminal gleams ahead like a mirage that might, this once, be real.",
        c("Take the airport ramp", "Airport Approach", "kia", 4, 1, 3, 3,
            listOf(ev(0.12, "Departure ramp jam. Everyone is late, everyone is honking. Solidarity in suffering.", dt = 8))),
        c("Get lost on the drop-off loop", "Departures", "departures", 3, 1, 2, 2)
    ),
    j("departures", "Departures Ramp",
        "You are AT the airport, circling the departures loop because a guard waved you the wrong way.",
        c("Just park and RUN", "Terminal Kerb", "kia", 3, 1, 2, 2,
            listOf(ev(0.15, "The kerb is 200m from the entrance. You run. You are, it turns out, not a runner.", dt = 5)))
    )
)

val scenario1: Scenario = Scenario(
    id = "s1",
    title = "Electronic City to Airport",
    subtitle = "Catch the 6:00 PM flight. 42 km. One chance.",
    goalNoun = "flight",
    startId = "ecity",
    goalId = "kia",
    goalName = "the Airport",
    winLine = "You are standing INSIDE the terminal. Against 42 kilometres, one frothing lake, " +
        "an immovable cow, and an entire civilization working actively against you — you made it. " +
        "The security queue is 45 minutes long. But that is a problem for a person who HAS A CHANCE. " +
        "Today, impossibly, that person is you.",
    junctions = s1List.associateBy { it.id }
)

// =====================================================================
// SCENARIO 2 — Jayanagar -> Whitefield office
// =====================================================================

private val s2List: List<Junction> = listOf(
    j("jayanagar", "Jayanagar 4th Block",
        "Filter coffee in hand, dread in heart. Whitefield is 24 km and one quiet breakdown away.",
        c("South End Circle toward BTM", "South End Road", "southend", 5, 2, 3, 3),
        c("Loop over the Jayadeva flyover", "Jayadeva", "jayadeva2", 6, 2, 4, 3,
            listOf(ev(0.35, "Jayadeva flyover: the noodle interchange claims another soul.", dt = 6, only = Vehicle.CAR))),
        c("Cut through Wilson Garden to the city", "Wilson Garden", "wilsongarden", 6, 2, 4, 3)
    ),
    j("southend", "South End Circle",
        "Six roads meet here and not one of them agrees on the rules of engagement.",
        c("Head to BTM", "100 Feet Road", "btm2", 5, 2, 3, 3),
        c("Cut toward Lalbagh and the city", "Lalbagh Road", "lalbagh", 6, 2, 3, 3)
    ),
    j("jayadeva2", "Jayadeva Flyover",
        "Three levels of interchange. You are now one strand of the noodle.",
        c("Descend toward BTM / Silk Board", "Outer Ring Road", "btm2", 6, 2, 4, 3)
    ),
    j("wilsongarden", "Wilson Garden",
        "Narrow lanes, parked cars on both sides, and a confidence that this was a good idea, rapidly fading.",
        c("Toward Lalbagh", "Hosur Road", "lalbagh", 5, 2, 3, 3),
        c("Push on to MG Road", "Richmond Road", "mgroad", 6, 2, 4, 3)
    ),
    j("lalbagh", "Lalbagh",
        "A beautiful garden you will not have time to enjoy. The traffic outside is its own kind of botanical.",
        c("Richmond Circle to MG Road", "Richmond Road", "mgroad", 6, 2, 3, 3,
            listOf(ev(0.35, "Richmond Circle. The signal cycle is longer than some marriages.", dt = 6, only = Vehicle.CAR))),
        c("Double Road toward Domlur", "Double Road", "domlur2", 6, 2, 3, 3)
    ),
    j("mgroad", "MG Road",
        "The old heart of the city. Beautiful, historic, and utterly, completely gridlocked.",
        c("Old Airport Road via Trinity", "Old Airport Road", "domlur2", 6, 2, 3, 3,
            listOf(ev(0.40, "Trinity Circle. The signal has a longer memory than you do.", dt = 7, only = Vehicle.CAR))),
        c("Ulsoor toward Indiranagar", "Ulsoor Road", "indiranagar2", 6, 2, 4, 3)
    ),
    j("btm2", "BTM Layout",
        "The one-way maze. Again. It is always, somehow, BTM.",
        c("Silk Board (yes, that one)", "Outer Ring Road", "silkboard2", 6, 2, 4, 3),
        c("Slip into Koramangala", "80 Feet Road", "koramangala2", 6, 2, 4, 3)
    ),
    j("koramangala2", "Koramangala",
        "Startup capital, cafe capital, and a road grid clearly drawn by someone's cat.",
        c("Sony World to Indiranagar", "Inner Ring Road", "indiranagar2", 6, 2, 3, 3,
            listOf(ev(0.35, "Sony World junction. Everyone edges forward; no one actually moves.", dt = 6, only = Vehicle.CAR))),
        c("Ejipura toward Sarjapur", "Ejipura", "sarjapur2", 7, 2, 4, 4,
            listOf(ev(0.40, "Ejipura's under-construction moonscape claims your suspension.", dh = 9, only = Vehicle.BIKE)))
    ),
    j("silkboard2", "CENTRAL SILK BOARD",
        "On the road to Whitefield you must, by ancient law, pay tribute to the traffic gods here.",
        c("ORR toward Marathahalli (HSR side)", "Outer Ring Road", "hsr2", 7, 2, 4, 4,
            listOf(
                ev(0.55, "Silk Board. You could have grown a full beard in this jam.", dt = 12, only = Vehicle.CAR),
                ev(0.10, "A cow has chosen this junction, of all places, to sit down and reflect.", dt = 6)
            )),
        c("Duck onto Sarjapur Road", "Sarjapur Road", "sarjapur2", 6, 2, 4, 4,
            listOf(ev(0.35, "Sarjapur potholes. Your kidneys have officially changed address.", dh = 9, only = Vehicle.BIKE)))
    ),
    j("hsr2", "HSR Layout",
        "Sector-numbered, tree-lined, and gridlocked with clinical precision.",
        c("Agara junction", "Outer Ring Road", "agara2", 5, 1, 3, 3),
        c("Sarjapur Road gamble", "Sarjapur Road", "sarjapur2", 6, 2, 4, 4)
    ),
    j("agara2", "Agara Junction",
        "The lake watches, unbothered, as you slowly lose your mind.",
        c("Push to Bellandur", "Outer Ring Road", "bellandur2", 6, 2, 3, 3),
        c("Iblur underpass", "Iblur", "iblur2", 5, 1, 3, 3,
            listOf(ev(0.30, "Iblur merge negotiations. Nobody blinks.", dt = 5, only = Vehicle.CAR)))
    ),
    j("iblur2", "Iblur Junction",
        "Merge here or be merged. Those are the only two options.",
        c("Onto ORR toward Bellandur", "Outer Ring Road", "bellandur2", 5, 1, 3, 3)
    ),
    j("sarjapur2", "Sarjapur Road",
        "Tech parks as far as the eye can see, potholes as deep as the eye can fall.",
        c("Cut to ORR at Bellandur", "Bellandur", "bellandur2", 6, 2, 4, 4,
            listOf(ev(0.35, "A pothole with its own postal code. You did not clear it.", dh = 10, only = Vehicle.BIKE))),
        c("Sarjapur to Kadubeesanahalli", "Kadubeesanahalli", "kadu2", 6, 2, 4, 3)
    ),
    j("bellandur2", "Bellandur",
        "The frothing lake. If it rained recently, this is where your day quietly ends.",
        c("ORR to Marathahalli", "Outer Ring Road", "marathahalli2", 6, 2, 4, 4,
            listOf(
                ev(0.30, "Waterlogging up to the door handles. Momentum: gone.", dt = 8, dh = 3),
                ev(0.06, "The lake reclaimed the road, your vehicle, and your 10 AM meeting.", fatal = true)
            )),
        c("Kadubeesanahalli tech-park crawl", "Kadubeesanahalli", "kadu2", 7, 2, 4, 3)
    ),
    j("kadu2", "Kadubeesanahalli",
        "The ORR service road, where every cab in the state is dropping someone off. Simultaneously. In front of you.",
        c("Grind on to Marathahalli", "Outer Ring Road", "marathahalli2", 7, 2, 4, 4,
            listOf(ev(0.40, "Cab drop-off gridlock. Twelve hazard lights, zero movement.", dt = 7, only = Vehicle.CAR)))
    ),
    j("domlur2", "Domlur",
        "The flyover, the signal, the eternal merge. Whitefield feels no closer than when you started.",
        c("Old Airport Road to Marathahalli", "Old Airport Road", "marathahalli2", 7, 2, 4, 3,
            listOf(ev(0.35, "Old Airport Road. Old-fashioned, dependable, immovable traffic.", dt = 7, only = Vehicle.CAR))),
        c("Indiranagar 100 Feet Road", "100 Feet Road", "indiranagar2", 6, 2, 3, 3)
    ),
    j("indiranagar2", "Indiranagar 100 Feet Road",
        "Every pub is full and every road is fuller.",
        c("Old Airport Road toward Marathahalli", "Old Airport Road", "marathahalli2", 6, 2, 3, 3,
            listOf(ev(0.30, "Metro pillars everywhere. The road is now a suggestion between barricades.", dt = 6))),
        c("CMH Road and the Metro works", "CMH Road", "marathahalli2", 7, 2, 4, 3)
    ),
    j("marathahalli2", "Marathahalli Bridge",
        "Whitefield is close now — close in the way the horizon is close.",
        c("ORR to Kundalahalli", "Outer Ring Road", "kundalahalli", 6, 2, 3, 3,
            listOf(ev(0.40, "Marathahalli signal cycles through green without you. Repeatedly. Pointedly.", dt = 7, only = Vehicle.CAR))),
        c("Varthur Road (the scenic swamp)", "Varthur Road", "varthur", 7, 2, 4, 4,
            listOf(ev(0.30, "Varthur Lake. It is either on fire or frothing. Possibly both.", dt = 6)))
    ),
    j("varthur", "Varthur",
        "You took the swamp route. The swamp is, so far, winning comfortably.",
        c("Struggle toward Whitefield", "Varthur Main Road", "aecs", 8, 2, 5, 4,
            listOf(ev(0.35, "Broken road, standing water, and a lorry that will not budge.", dh = 8, only = Vehicle.BIKE)))
    ),
    j("kundalahalli", "Kundalahalli Gate",
        "The last real gauntlet before Whitefield proper. So close. So very not there yet.",
        c("Whitefield Main Road via AECS", "AECS Layout", "aecs", 6, 2, 3, 3),
        c("Brookefield shortcut", "Brookefield", "brookefield", 6, 2, 4, 3)
    ),
    j("aecs", "AECS Layout",
        "A grid of identical lanes, each one convinced it is the way out.",
        c("Toward Hoodi", "Whitefield Road", "hoodi", 6, 2, 3, 3,
            listOf(ev(0.30, "Hoodi railway gate. Closed. For a train. That is taking its time.", dt = 6))),
        c("Cut across to Brookefield", "Brookefield", "brookefield", 6, 2, 4, 3)
    ),
    j("hoodi", "Hoodi",
        "Glass towers on every side. Somewhere in one of them, your meeting is starting without you.",
        c("Final approach via ITPL", "ITPL Main Road", "itpl", 6, 2, 3, 3)
    ),
    j("brookefield", "Brookefield",
        "Malls, apartments, and a road that funnels every one of them into a single signal.",
        c("Push toward ITPL", "ITPL Main Road", "itpl", 6, 2, 3, 3,
            listOf(ev(0.35, "The tech-park entry queue. Ten thousand ID cards ahead of yours.", dt = 6, only = Vehicle.CAR)))
    ),
    j("itpl", "ITPL Main Road",
        "The office is in sight. The office parking, cruelly, is not.",
        c("Reach the office", "Whitefield", "whitefield", 5, 1, 3, 3,
            listOf(ev(0.15, "You circle the parking like a vulture. A spot opens. Someone smaller takes it.", dt = 5)))
    )
)

val scenario2: Scenario = Scenario(
    id = "s2",
    title = "Jayanagar to Whitefield",
    subtitle = "Reach the 10:00 AM meeting. 24 km across the whole city.",
    goalNoun = "meeting",
    startId = "jayanagar",
    goalId = "whitefield",
    goalName = "the Whitefield office",
    winLine = "You walk into the meeting room. You are, against every law of Bangalore, ON TIME. " +
        "Silk Board tried. Sarjapur tried. Varthur's frothing swamp tried. They all failed. " +
        "Your colleagues, still stuck somewhere near ORR, will not believe this. " +
        "You barely believe it. Sit down. Act casual. You have earned this.",
    junctions = s2List.associateBy { it.id }
)
