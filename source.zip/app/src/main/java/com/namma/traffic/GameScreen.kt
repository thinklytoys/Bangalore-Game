package com.namma.traffic

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Amber = Color(0xFFFFB74D)
private val Cyan = Color(0xFF4DD0E1)
private val Green = Color(0xFF81C784)
private val Red = Color(0xFFEF5350)
private val Track = Color(0xFF33333F)

sealed interface AppScreen {
    data object Home : AppScreen
    data class Garage(val scenario: Scenario) : AppScreen
    data class Play(val run: RunState) : AppScreen
    data class End(val run: RunState, val result: EndResult) : AppScreen
}

@Composable
fun GameApp() {
    val colors = darkColorScheme(
        primary = Amber,
        onPrimary = Color(0xFF1A1206),
        background = Color(0xFF0F0F16),
        onBackground = Color(0xFFECEAF2),
        surface = Color(0xFF1B1B27),
        onSurface = Color(0xFFECEAF2),
        surfaceVariant = Color(0xFF262636),
        onSurfaceVariant = Color(0xFFB9B7C6),
        error = Red
    )
    MaterialTheme(colorScheme = colors) {
        var screen by remember { mutableStateOf<AppScreen>(AppScreen.Home) }
        val rng = remember { Random(System.nanoTime()) }

        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            when (val s = screen) {
                is AppScreen.Home -> HomeView(onPick = { screen = AppScreen.Garage(it) })

                is AppScreen.Garage -> GarageView(
                    scenario = s.scenario,
                    onBack = { screen = AppScreen.Home },
                    onGo = { v -> screen = AppScreen.Play(startRun(s.scenario, v)) }
                )

                is AppScreen.Play -> {
                    val scenario = scenarioById(s.run.scenarioId)
                    if (scenario == null) {
                        screen = AppScreen.Home
                    } else {
                        PlayView(
                            scenario = scenario,
                            run = s.run,
                            onChoice = { choice ->
                                when (val r = takeChoice(scenario, s.run, choice, rng)) {
                                    is StepResult.Go -> screen = AppScreen.Play(r.run)
                                    is StepResult.End -> screen = AppScreen.End(r.run, r.result)
                                }
                            },
                            onQuit = { screen = AppScreen.Home }
                        )
                    }
                }

                is AppScreen.End -> EndView(
                    result = s.result,
                    onRetry = {
                        val sc = scenarioById(s.run.scenarioId)
                        screen = if (sc != null) AppScreen.Garage(sc) else AppScreen.Home
                    },
                    onHome = { screen = AppScreen.Home }
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Home

@Composable
private fun HomeView(onPick: (Scenario) -> Unit) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("NAMMA", color = Amber, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Text("TRAFFIC", color = MaterialTheme.colorScheme.onBackground, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text(
            "A Bangalore commute simulator. You will probably not make it. That is the point.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 15.sp
        )
        Spacer(Modifier.height(28.dp))
        Text("PICK YOUR ORDEAL", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        for (sc in Scenarios.all) {
            ScenarioCard(sc, onClick = { onPick(sc) })
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Keep both bars above zero and reach the end. Roughly 1.7% of people do. Good luck.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ScenarioCard(sc: Scenario, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(sc.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(sc.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        }
    }
}

// -------------------------------------------------------------- Garage

@Composable
private fun GarageView(scenario: Scenario, onBack: () -> Unit, onGo: (Vehicle) -> Unit) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text(scenario.title, color = Amber, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text(scenario.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Text("CHOOSE YOUR VEHICLE", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        VehicleCard(
            title = "Car",
            pitch = "Slow but safe. Time drains fast in the jams; your body stays intact. You will mostly lose to the clock.",
            accent = Cyan,
            onClick = { onGo(Vehicle.CAR) }
        )
        Spacer(Modifier.height(12.dp))
        VehicleCard(
            title = "Bike",
            pitch = "Fast but fragile. You weave past the jams, but every pothole is a gamble. You will mostly lose to injury.",
            accent = Green,
            onClick = { onGo(Vehicle.BIKE) }
        )

        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onBack) {
            Text("Back", maxLines = 1, softWrap = false)
        }
    }
}

@Composable
private fun VehicleCard(title: String, pitch: String, accent: Color, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Text(pitch, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        }
    }
}

// ---------------------------------------------------------------- Play

@Composable
private fun PlayView(
    scenario: Scenario,
    run: RunState,
    onChoice: (Choice) -> Unit,
    onQuit: () -> Unit
) {
    val junction = junctionOf(scenario, run.currentId)
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(scroll)
    ) {
        Spacer(Modifier.height(16.dp))
        StatBar("TIME", run.time, Cyan)
        Spacer(Modifier.height(10.dp))
        StatBar("HEALTH", run.health, Green)
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (run.vehicle == Vehicle.BIKE) "On the bike" else "In the car",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1, softWrap = false
            )
            Text("Junction ${run.steps}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1, softWrap = false)
        }

        Spacer(Modifier.height(18.dp))

        if (junction == null) {
            Text("You have driven off the edge of the known map.", color = Red, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onQuit) { Text("Home", maxLines = 1, softWrap = false) }
            return@Column
        }

        Text(junction.name.uppercase(), color = Amber, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text(junction.blurb, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)

        if (run.eventLine != null) {
            Spacer(Modifier.height(12.dp))
            Surface(color = Color(0xFF3A2A12), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    run.eventLine,
                    color = Amber,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        for (choice in junction.choices) {
            ChoiceCard(choice, onClick = { onChoice(choice) })
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onQuit) {
            Text("Give up (go home)", maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ChoiceCard(choice: Choice, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(choice.label, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "via ${choice.road}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun StatBar(label: String, value: Int, full: Color) {
    val frac by animateFloatAsState(
        targetValue = (value / 100f).coerceIn(0f, 1f),
        label = "bar"
    )
    val color = when {
        value > 50 -> full
        value > 25 -> Amber
        else -> Red
    }
    Column(Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            Text("$value", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Track)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(frac)
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(color)
            )
        }
    }
}

// ----------------------------------------------------------------- End

@Composable
private fun EndView(result: EndResult, onRetry: () -> Unit, onHome: () -> Unit) {
    val context = LocalContext.current
    val scroll = rememberScrollState()
    val headColor = if (result.won) Green else Red

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text(result.headline, color = headColor, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text(result.causeTag, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(20.dp))
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Text(result.line, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, modifier = Modifier.padding(16.dp))
        }

        Spacer(Modifier.height(14.dp))
        Text(result.rankLine, color = Amber, fontSize = 14.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(28.dp))
        Button(
            onClick = { shareText(context, result.shareText) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1206))
        ) {
            Text("Share this", fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onRetry, modifier = Modifier.weight(1f)) {
                Text("Try again", maxLines = 1, softWrap = false)
            }
            OutlinedButton(onClick = onHome, modifier = Modifier.weight(1f)) {
                Text("Home", maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

private fun shareText(context: Context, text: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, "Share your commute"))
    } catch (t: Throwable) {
        // If no share app is available, fail quietly rather than crash.
    }
}
