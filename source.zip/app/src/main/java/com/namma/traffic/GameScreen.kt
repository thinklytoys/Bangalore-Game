package com.namma.traffic

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Amber = Color(0xFFFFB74D)
private val Cyan = Color(0xFF4DD0E1)
private val Green = Color(0xFF81C784)
private val Red = Color(0xFFEF5350)
private val Track = Color(0xFF33333F)

sealed interface AppScreen {
    data class Intro(val page: Int) : AppScreen
    data object Home : AppScreen
    data class Garage(val scenario: Scenario) : AppScreen
    data class Play(val run: RunState) : AppScreen
    data class End(val run: RunState, val result: EndResult) : AppScreen
}

@Composable
fun GameApp() {
    val colors = darkColorScheme(
        primary = Amber,
        onPrimary = Color(0xFF1A1206),
        background = Color(0xFF0F0F16),
        onBackground = Color(0xFFECEAF2),
        surface = Color(0xFF1B1B27),
        onSurface = Color(0xFFECEAF2),
        surfaceVariant = Color(0xFF262636),
        onSurfaceVariant = Color(0xFFB9B7C6),
        error = Red
    )
    MaterialTheme(colorScheme = colors) {
        var screen by remember { mutableStateOf<AppScreen>(AppScreen.Intro(0)) }
        val rng = remember { Random(System.nanoTime()) }

        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            when (val s = screen) {
                is AppScreen.Intro -> IntroView(
                    page = s.page,
                    onNext = {
                        screen = if (s.page + 1 < introPages.size) AppScreen.Intro(s.page + 1) else AppScreen.Home
                    },
                    onSkip = { screen = AppScreen.Home }
                )

                is AppScreen.Home -> HomeView(onPick = { screen = AppScreen.Garage(it) })

                is AppScreen.Garage -> GarageView(
                    scenario = s.scenario,
                    onBack = { screen = AppScreen.Home },
                    onGo = { v -> screen = AppScreen.Play(startRun(s.scenario, v)) }
                )

                is AppScreen.Play -> {
                    val scenario = scenarioById(s.run.scenarioId)
                    if (scenario == null) {
                        screen = AppScreen.Home
                    } else {
                        PlayView(
                            scenario = scenario,
                            run = s.run,
                            onChoice = { choice ->
                                when (val r = takeChoice(scenario, s.run, choice, rng)) {
                                    is StepResult.Go -> screen = AppScreen.Play(r.run)
                                    is StepResult.End -> screen = AppScreen.End(r.run, r.result)
                                }
                            },
                            onQuit = { screen = AppScreen.Home }
                        )
                    }
                }

                is AppScreen.End -> EndView(
                    result = s.result,
                    onRetry = {
                        val sc = scenarioById(s.run.scenarioId)
                        screen = if (sc != null) AppScreen.Garage(sc) else AppScreen.Home
                    },
                    onHome = { screen = AppScreen.Home }
                )
            }
        }
    }
}

// --------------------------------------------------------------- Intro

private data class IntroPage(
    val heading: String,
    val body: String,
    val signoff: String? = null,
    val cta: String = "Continue"
)

private val introPages = listOf(
    IntroPage(
        heading = "Namaskara, guru.",
        body = "Hi, I'm Dibakar, and I live in Bangalore — a city I genuinely love, and a city " +
            "that tests that love twice a day, every single day, somewhere around Silk Board."
    ),
    IntroPage(
        heading = "So here's the idea.",
        body = "I've lost whole chunks of my life stuck between a pothole and a signal that seems to " +
            "hate me personally. Instead of losing my mind, I turned all that traffic rage into a little game. " +
            "Think of it as group therapy for anyone who's ever watched a flight leave without them."
    ),
    IntroPage(
        heading = "One challenge.",
        body = "Bangalore traffic does not go easy on anyone. Time and health both drain as you move, " +
            "and the city throws jams, potholes, and worse in your way. Let's see if you can actually " +
            "reach your destination. Chalo. Pick your ordeal, and have some fun with your frustration.",
        signoff = "Made with \u2764 and frustration, from Bangalore.",
        cta = "Let's go"
    )
)

@Composable
private fun IntroView(page: Int, onNext: () -> Unit, onSkip: () -> Unit) {
    val p = introPages.getOrElse(page) { introPages.last() }
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(24.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("NAMMA TRAFFIC", color = Amber, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1, softWrap = false)
        Spacer(Modifier.height(40.dp))
        Text(p.heading, color = MaterialTheme.colorScheme.onBackground, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))
        Text(p.body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 17.sp)

        if (p.signoff != null) {
            Spacer(Modifier.height(20.dp))
            Text(p.signoff, color = Amber, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(32.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            for (i in introPages.indices) {
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .height(8.dp)
                        .width(if (i == page) 22.dp else 8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (i == page) Amber else Track)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onNext,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1206))
        ) {
            Text(p.cta + "  \u2192", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        if (page < introPages.size - 1) {
            OutlinedButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) {
                Text("Skip intro", maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ---------------------------------------------------------------- Home

@Composable
private fun HomeView(onPick: (Scenario) -> Unit) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("NAMMA", color = Amber, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Text("TRAFFIC", color = MaterialTheme.colorScheme.onBackground, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text(
            "A Bangalore commute simulator. Let's see if you can actually reach your destination.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 15.sp
        )
        Spacer(Modifier.height(28.dp))
        Text("PICK YOUR ORDEAL", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        for (sc in Scenarios.all) {
            ScenarioCard(sc, onClick = { onPick(sc) })
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Keep both bars above zero and reach the end. Good luck out there.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ScenarioCard(sc: Scenario, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(sc.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(sc.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        }
    }
}

// -------------------------------------------------------------- Garage

@Composable
private fun GarageView(scenario: Scenario, onBack: () -> Unit, onGo: (Vehicle) -> Unit) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text(scenario.title, color = Amber, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text(scenario.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Text("CHOOSE YOUR VEHICLE", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        VehicleCard(
            title = "Car",
            pitch = "Slow but safe. Time drains fast in the jams; your body stays intact. You will mostly lose to the clock.",
            accent = Cyan,
            onClick = { onGo(Vehicle.CAR) }
        )
        Spacer(Modifier.height(12.dp))
        VehicleCard(
            title = "Bike",
            pitch = "Fast but fragile. You weave past the jams, but every pothole is a gamble. You will mostly lose to injury.",
            accent = Green,
            onClick = { onGo(Vehicle.BIKE) }
        )

        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onBack) {
            Text("Back", maxLines = 1, softWrap = false)
        }
    }
}

@Composable
private fun VehicleCard(title: String, pitch: String, accent: Color, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Text(pitch, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        }
    }
}

// ---------------------------------------------------------------- Play

@Composable
private fun PlayView(
    scenario: Scenario,
    run: RunState,
    onChoice: (Choice) -> Unit,
    onQuit: () -> Unit
) {
    val junction = junctionOf(scenario, run.currentId)
    val scroll = rememberScrollState()
    val haptic = LocalHapticFeedback.current

    fun tap(choice: Choice) {
        try {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        } catch (t: Throwable) {
            // some devices have no haptic engine; ignore
        }
        onChoice(choice)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .verticalScroll(scroll)
    ) {
        // top margin so the bars clear the notch / punch-hole camera
        Spacer(Modifier.height(28.dp))
        StatBar("TIME", run.time, Cyan)
        Spacer(Modifier.height(10.dp))
        StatBar("HEALTH", run.health, Green)
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (run.vehicle == Vehicle.BIKE) "On the bike" else "In the car",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1, softWrap = false
            )
            Text("Junction ${run.steps}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 1, softWrap = false)
        }

        Spacer(Modifier.height(16.dp))

        if (junction == null) {
            Text("You have driven off the edge of the known map.", color = Red, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onQuit) { Text("Home", maxLines = 1, softWrap = false) }
            return@Column
        }

        SceneArt(junction.scene)
        Spacer(Modifier.height(14.dp))

        Text(junction.name.uppercase(), color = Amber, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text(junction.blurb, color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp)

        if (run.eventLine != null) {
            Spacer(Modifier.height(12.dp))
            Surface(color = Color(0xFF3A2A12), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    run.eventLine,
                    color = Amber,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        val choices = junction.choices
        if (choices.size == 1) {
            // story beat: one prominent Continue button, no decision to agonise over
            val only = choices[0]
            Button(
                onClick = { tap(only) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1206))
            ) {
                Text(only.label + "  →", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            for (choice in choices) {
                ChoiceCard(choice, onClick = { tap(choice) })
                Spacer(Modifier.height(10.dp))
            }
        }

        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = onQuit) {
            Text("Give up (go home)", maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ChoiceCard(choice: Choice, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(choice.label, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (choice.road.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "via ${choice.road}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// -------------------------------------------------------- Scene graphics
// Original vector art drawn at runtime — no bundled photos, works offline.

@Composable
private fun SceneArt(scene: Scene) {
    val sky = Color(0xFF171722)
    val road = Color(0xFF3A3A46)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(116.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(sky)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val roadTop = h * 0.60f

            fun band() {
                drawRect(color = road, topLeft = Offset(0f, roadTop), size = Size(w, h - roadTop))
            }

            fun dashes(y: Float) {
                var x = w * 0.05f
                while (x < w * 0.95f) {
                    drawRect(Amber, topLeft = Offset(x, y), size = Size(w * 0.06f, h * 0.025f))
                    x += w * 0.15f
                }
            }

            when (scene) {
                Scene.JAM -> {
                    band()
                    val cars = listOf(Color(0xFFEF5350), Color(0xFF4DD0E1), Color(0xFFFFB74D), Color(0xFF81C784), Color(0xFFBA68C8))
                    var x = w * 0.06f; var i = 0
                    while (x < w * 0.9f) {
                        drawRect(cars[i % cars.size], Offset(x, roadTop + h * 0.05f), Size(w * 0.11f, h * 0.15f)); x += w * 0.16f; i++
                    }
                    x = w * 0.12f; i = 2
                    while (x < w * 0.85f) {
                        drawRect(cars[i % cars.size], Offset(x, roadTop + h * 0.24f), Size(w * 0.11f, h * 0.12f)); x += w * 0.2f; i++
                    }
                }
                Scene.SIGNAL -> {
                    band(); dashes(h * 0.78f)
                    drawRect(Color(0xFF22222E), Offset(w * 0.80f, h * 0.12f), Size(w * 0.10f, h * 0.44f))
                    drawCircle(Color(0xFFEF5350), h * 0.05f, Offset(w * 0.85f, h * 0.20f))
                    drawCircle(Color(0xFFFFB74D), h * 0.05f, Offset(w * 0.85f, h * 0.32f))
                    drawCircle(Color(0xFF81C784), h * 0.05f, Offset(w * 0.85f, h * 0.44f))
                }
                Scene.POTHOLE -> {
                    band(); dashes(h * 0.72f)
                    drawOval(Color(0xFF0C0C12), Offset(w * 0.34f, roadTop + h * 0.10f), Size(w * 0.32f, h * 0.22f))
                    drawOval(Color(0xFF000000), Offset(w * 0.40f, roadTop + h * 0.14f), Size(w * 0.20f, h * 0.13f))
                }
                Scene.FLOOD -> {
                    band()
                    drawRect(Color(0xCC2A6C8F), Offset(0f, roadTop + h * 0.06f), Size(w, h - roadTop - h * 0.06f))
                    drawCircle(Color(0x552A6C8F), h * 0.05f, Offset(w * 0.25f, roadTop + h * 0.04f))
                    drawCircle(Color(0x552A6C8F), h * 0.05f, Offset(w * 0.6f, roadTop + h * 0.05f))
                }
                Scene.RAIN -> {
                    band(); dashes(h * 0.78f)
                    var x = w * 0.05f
                    while (x < w) {
                        drawLine(Color(0x884DD0E1), Offset(x, h * 0.08f), Offset(x - w * 0.05f, h * 0.5f), 2f, cap = StrokeCap.Round)
                        x += w * 0.09f
                    }
                }
                Scene.MARKET -> {
                    band()
                    val cols = listOf(Color(0xFFEF5350), Color(0xFFFFB74D), Color(0xFF81C784), Color(0xFF4DD0E1))
                    var x = w * 0.08f; var i = 0
                    while (x < w * 0.9f) {
                        val p = Path().apply {
                            moveTo(x, roadTop); lineTo(x + w * 0.06f, roadTop - h * 0.18f); lineTo(x + w * 0.12f, roadTop); close()
                        }
                        drawPath(p, cols[i % cols.size]); x += w * 0.14f; i++
                    }
                }
                Scene.FLYOVER -> {
                    band()
                    drawRect(Color(0xFF4A4A58), Offset(0f, h * 0.28f), Size(w, h * 0.12f))
                    drawRect(Color(0xFF4A4A58), Offset(w * 0.2f, h * 0.40f), Size(w * 0.05f, h * 0.20f))
                    drawRect(Color(0xFF4A4A58), Offset(w * 0.7f, h * 0.40f), Size(w * 0.05f, h * 0.20f))
                    dashes(h * 0.32f)
                }
                Scene.TECHPARK -> {
                    band()
                    val bx = listOf(0.10f, 0.34f, 0.58f, 0.78f)
                    val bh2 = listOf(0.42f, 0.30f, 0.50f, 0.36f)
                    for (k in bx.indices) {
                        val x = w * bx[k]; val bh3 = h * bh2[k]
                        drawRect(Color(0xFF2E2E3C), Offset(x, roadTop - bh3), Size(w * 0.16f, bh3))
                        var yy = roadTop - bh3 + h * 0.05f
                        while (yy < roadTop - h * 0.03f) {
                            drawRect(Color(0xFFFFD27A), Offset(x + w * 0.03f, yy), Size(w * 0.03f, h * 0.04f))
                            drawRect(Color(0xFFFFD27A), Offset(x + w * 0.09f, yy), Size(w * 0.03f, h * 0.04f))
                            yy += h * 0.10f
                        }
                    }
                }
                Scene.HIGHWAY -> {
                    val p = Path().apply {
                        moveTo(0f, h); lineTo(w * 0.4f, h * 0.30f); lineTo(w * 0.6f, h * 0.30f); lineTo(w, h); close()
                    }
                    drawPath(p, road)
                    var t = 0f; var seg = 0
                    while (t < 1f) {
                        val yy = h * 0.30f + (h - h * 0.30f) * t
                        val cx = w * 0.5f
                        val hw = (w * 0.02f) + (w * 0.05f) * t
                        if (seg % 2 == 0) drawRect(Amber, Offset(cx - hw / 2, yy), Size(hw, h * 0.03f + h * 0.02f * t))
                        t += 0.14f; seg++
                    }
                }
                Scene.TOLL -> {
                    band(); dashes(h * 0.80f)
                    drawRect(Color(0xFF22222E), Offset(w * 0.06f, h * 0.20f), Size(w * 0.06f, h * 0.30f))
                    var x = w * 0.12f; var i = 0
                    while (x < w * 0.94f) {
                        drawRect(if (i % 2 == 0) Color(0xFFEF5350) else Color(0xFFECEAF2), Offset(x, h * 0.30f), Size(w * 0.08f, h * 0.06f)); x += w * 0.08f; i++
                    }
                }
                Scene.COW -> {
                    band(); dashes(h * 0.82f)
                    drawOval(Color(0xFFECEAF2), Offset(w * 0.34f, roadTop - h * 0.02f), Size(w * 0.30f, h * 0.20f))
                    drawOval(Color(0xFFECEAF2), Offset(w * 0.58f, roadTop - h * 0.06f), Size(w * 0.12f, h * 0.12f))
                    for (lx in listOf(0.38f, 0.46f, 0.54f, 0.60f)) {
                        drawLine(Color(0xFFECEAF2), Offset(w * lx, roadTop + h * 0.16f), Offset(w * lx, roadTop + h * 0.30f), 4f)
                    }
                }
                Scene.DEADEND -> {
                    band(); dashes(h * 0.80f)
                    var x = w * 0.16f; var i = 0
                    while (x < w * 0.9f) {
                        drawRect(if (i % 2 == 0) Color(0xFFEF5350) else Color(0xFFECEAF2), Offset(x, h * 0.30f), Size(w * 0.09f, h * 0.05f)); x += w * 0.09f; i++
                    }
                    drawLine(Color(0xFFEF5350), Offset(w * 0.40f, h * 0.14f), Offset(w * 0.60f, h * 0.30f), 6f, cap = StrokeCap.Round)
                    drawLine(Color(0xFFEF5350), Offset(w * 0.60f, h * 0.14f), Offset(w * 0.40f, h * 0.30f), 6f, cap = StrokeCap.Round)
                }
                Scene.FINISH -> {
                    band()
                    var x = 0f; var i = 0
                    while (x < w) {
                        var row = 0
                        while (row < 3) {
                            val on = (i + row) % 2 == 0
                            drawRect(if (on) Color(0xFFECEAF2) else Color(0xFF22222E), Offset(x, roadTop + row * (h - roadTop) / 3f), Size(w * 0.08f, (h - roadTop) / 3f)); row++
                        }
                        x += w * 0.08f; i++
                    }
                    // little plane
                    val p = Path().apply {
                        moveTo(w * 0.5f, h * 0.10f); lineTo(w * 0.62f, h * 0.30f); lineTo(w * 0.5f, h * 0.26f); lineTo(w * 0.38f, h * 0.30f); close()
                    }
                    drawPath(p, Amber)
                }
                Scene.START -> {
                    band(); dashes(h * 0.78f)
                    drawRect(Color(0xFF22222E), Offset(w * 0.08f, h * 0.14f), Size(w * 0.04f, h * 0.42f))
                    val p = Path().apply {
                        moveTo(w * 0.12f, h * 0.16f); lineTo(w * 0.30f, h * 0.22f); lineTo(w * 0.12f, h * 0.30f); close()
                    }
                    drawPath(p, Amber)
                }
                else -> {
                    band(); dashes(h * 0.78f)
                }
            }
        }
    }
}

@Composable
private fun StatBar(label: String, value: Int, full: Color) {
    val frac by animateFloatAsState(
        targetValue = (value / 100f).coerceIn(0f, 1f),
        label = "bar"
    )
    val color = when {
        value > 50 -> full
        value > 25 -> Amber
        else -> Red
    }
    Column(Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            Text("$value", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Track)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(frac)
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(color)
            )
        }
    }
}

// ----------------------------------------------------------------- End

@Composable
private fun EndView(result: EndResult, onRetry: () -> Unit, onHome: () -> Unit) {
    val context = LocalContext.current
    val scroll = rememberScrollState()
    val headColor = if (result.won) Green else Red

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text(result.headline, color = headColor, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text(result.causeTag, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(20.dp))
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Text(result.line, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, modifier = Modifier.padding(16.dp))
        }

        Spacer(Modifier.height(14.dp))
        Text(result.rankLine, color = Amber, fontSize = 14.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(28.dp))
        Button(
            onClick = { shareText(context, result.shareText) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A1206))
        ) {
            Text("Share this", fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onRetry, modifier = Modifier.weight(1f)) {
                Text("Try again", maxLines = 1, softWrap = false)
            }
            OutlinedButton(onClick = onHome, modifier = Modifier.weight(1f)) {
                Text("Home", maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

private fun shareText(context: Context, text: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, "Share your commute"))
    } catch (t: Throwable) {
        // If no share app is available, fail quietly rather than crash.
    }
}
