package com.namma.traffic

import kotlin.math.roundToInt
import kotlin.random.Random

enum class Vehicle { CAR, BIKE }

enum class Scene {
    START, ROAD, JAM, SIGNAL, POTHOLE, FLOOD, RAIN, MARKET,
    FLYOVER, TECHPARK, HIGHWAY, TOLL, COW, DEADEND, FINISH
}

// ---------------------------------------------------------------------
// DIFFICULTY TUNING
// Reaching the destination is meant to be rare - most runs should end in
// a funny failure, with only a small, bragworthy fraction making it.
// These numbers were calibrated by simulating thousands of runs against
// the actual map data (see project notes) rather than guessed, since the
// two scenarios are very different lengths and need different scaling.
//
// - scenarioMultiplier: scales every base time/health cost per hop, per
//   scenario and per vehicle (a longer route needs a smaller multiplier
//   to reach the same difficulty as a shorter one).
// - minBikeHealthDrain: many "story beat" hops have a near-zero written
//   health cost for the bike (they're mid-conversation, not a hazard).
//   Without a floor, the bike could coast through most of the map for
//   free and never feel the road at all. This guarantees every hop wears
//   the bike down at least a little, so health genuinely runs out.
// - fatalChanceMultiplier: instant-death events are dialed back so most
//   bike losses come from watching the health bar run out - which feels
//   fair - rather than a random instant death, which feels cheap.
// ---------------------------------------------------------------------

private fun scenarioMultiplier(scenarioId: String, vehicle: Vehicle): Double = when (scenarioId) {
    "s1" -> if (vehicle == Vehicle.CAR) 1.5 else 1.3
    "s2" -> if (vehicle == Vehicle.CAR) 3.6 else 2.0
    else -> 1.8
}

private fun minBikeHealthDrain(scenarioId: String): Double = if (scenarioId == "s2") 4.0 else 2.3
private const val MIN_BIKE_TIME_DRAIN = 1.0
private const val FATAL_CHANCE_MULTIPLIER = 0.5

data class GameEvent(
    val chance: Double,
    val line: String,
    val timeHit: Int = 0,
    val healthHit: Int = 0,
    val only: Vehicle? = null,
    val fatal: Boolean = false
)

data class Choice(
    val label: String,
    val road: String,
    val to: String,
    val carTime: Int,
    val carHealth: Int,
    val bikeTime: Int,
    val bikeHealth: Int,
    val events: List<GameEvent> = emptyList()
)

data class Junction(
    val id: String,
    val name: String,
    val blurb: String,
    val choices: List<Choice>,
    val scene: Scene = Scene.ROAD
)

data class Scenario(
    val id: String,
    val title: String,
    val subtitle: String,
    val goalNoun: String,     // "flight" or "meeting"
    val startId: String,
    val goalId: String,
    val goalName: String,     // "the Airport" / "the Whitefield office"
    val winLine: String,
    val junctions: Map<String, Junction>
)

data class RunState(
    val scenarioId: String,
    val vehicle: Vehicle,
    val currentId: String,
    val time: Int,
    val health: Int,
    val steps: Int,
    val eventLine: String? = null
)

data class EndResult(
    val won: Boolean,
    val headline: String,
    val causeTag: String,
    val line: String,
    val rankLine: String,
    val shareText: String
)

sealed interface StepResult {
    data class Go(val run: RunState) : StepResult
    data class End(val result: EndResult, val run: RunState) : StepResult
}

fun scenarioById(id: String): Scenario? = Scenarios.all.firstOrNull { it.id == id }

fun junctionOf(scenario: Scenario, id: String): Junction? = scenario.junctions[id]

fun startRun(scenario: Scenario, vehicle: Vehicle): RunState =
    RunState(
        scenarioId = scenario.id,
        vehicle = vehicle,
        currentId = scenario.startId,
        time = 100,
        health = 100,
        steps = 0,
        eventLine = null
    )

fun takeChoice(scenario: Scenario, run: RunState, choice: Choice, rng: Random): StepResult {
    var time = run.time
    var health = run.health
    val v = run.vehicle
    val mult = scenarioMultiplier(scenario.id, v)

    if (v == Vehicle.CAR) {
        time -= (choice.carTime * mult).roundToInt()
        health -= (choice.carHealth * mult).roundToInt()
    } else {
        val flooredTime = maxOf(choice.bikeTime.toDouble(), MIN_BIKE_TIME_DRAIN)
        val flooredHealth = maxOf(choice.bikeHealth.toDouble(), minBikeHealthDrain(scenario.id))
        time -= (flooredTime * mult).roundToInt()
        health -= (flooredHealth * mult).roundToInt()
    }

    var eventLine: String? = null
    var fatalLine: String? = null
    for (e in choice.events) {
        if (e.only != null && e.only != v) continue
        val chance = if (e.fatal) e.chance * FATAL_CHANCE_MULTIPLIER else e.chance
        if (rng.nextDouble() <= chance) {
            time -= (e.timeHit * mult).roundToInt()
            health -= (e.healthHit * mult).roundToInt()
            eventLine = e.line
            if (e.fatal) {
                fatalLine = e.line
                break
            }
        }
    }

    time = time.coerceIn(0, 100)
    health = health.coerceIn(0, 100)

    val newRun = run.copy(
        currentId = choice.to,
        time = time,
        health = health,
        steps = run.steps + 1,
        eventLine = eventLine
    )

    if (fatalLine != null) {
        return StepResult.End(makeFatalEnd(scenario, newRun, fatalLine), newRun)
    }
    if (time <= 0) {
        return StepResult.End(makeTimeEnd(scenario, newRun, rng), newRun)
    }
    if (health <= 0) {
        return StepResult.End(makeHealthEnd(scenario, newRun, rng), newRun)
    }
    if (choice.to == scenario.goalId) {
        return StepResult.End(makeWinEnd(scenario, newRun), newRun)
    }
    return StepResult.Go(newRun)
}

private fun pick(list: List<String>, rng: Random): String =
    if (list.isEmpty()) "Something went very Bangalore." else list[rng.nextInt(list.size)]

private fun vh(run: RunState): String = if (run.vehicle == Vehicle.BIKE) "bike" else "car"

fun buildShare(won: Boolean, s: Scenario, run: RunState, line: String): String {
    return if (won) {
        "I actually reached ${s.goalName} in NAMMA TRAFFIC on a ${vh(run)} " +
            "with ${run.time}% time and ${run.health}% health to spare. " +
            "Only about 1.7% of Bengalureans make it. Think you can beat Bangalore?"
    } else {
        "NAMMA TRAFFIC: I did NOT make it. $line " +
            "Bet you can't reach ${s.goalName} either. Try it."
    }
}

fun makeWinEnd(s: Scenario, run: RunState): EndResult {
    val rank = "Roughly 1.7% of Bengalureans reach on the first try. Today, impossibly, that is you."
    return EndResult(
        won = true,
        headline = "YOU MADE IT.",
        causeTag = "Survived on a ${vh(run)}: ${run.time}% time and ${run.health}% health left.",
        line = s.winLine,
        rankLine = rank,
        shareText = buildShare(true, s, run, s.winLine)
    )
}

fun makeTimeEnd(s: Scenario, run: RunState, rng: Random): EndResult {
    val line = pick(Endings.timeFails, rng)
    val kicker = if (s.goalNoun == "flight")
        "Boarding closed. The plane is a dot in the sky now."
    else
        "The meeting started without you. Your empty chair is speaking volumes."
    val body = "$line $kicker"
    return EndResult(
        won = false,
        headline = "OUT OF TIME",
        causeTag = "Cause of delay: Bangalore (natural causes)",
        line = body,
        rankLine = "You ground through ${run.steps} junctions before the clock won.",
        shareText = buildShare(false, s, run, body)
    )
}

fun makeHealthEnd(s: Scenario, run: RunState, rng: Random): EndResult {
    val pool = if (run.vehicle == Vehicle.BIKE) Endings.bikeHealthFails else Endings.carHealthFails
    val line = pick(pool, rng)
    val dest = if (s.goalNoun == "flight") "the airport" else "the office"
    val body = "$line Instead of $dest, you are now at the nearest hospital, filling out forms with your good hand."
    return EndResult(
        won = false,
        headline = "GAME OVER — HOSPITAL",
        causeTag = "Cause of injury: the road, winning as always",
        line = body,
        rankLine = "You made it ${run.steps} junctions before the road made an example of you.",
        shareText = buildShare(false, s, run, body)
    )
}

fun makeFatalEnd(s: Scenario, run: RunState, line: String): EndResult {
    return EndResult(
        won = false,
        headline = "GAME OVER",
        causeTag = "Cause: a deeply Bangalore ending",
        line = line,
        rankLine = "Down at junction ${run.steps}. So close. So very not close.",
        shareText = buildShare(false, s, run, line)
    )
}

object Endings {
    val timeFails = listOf(
        "You watched the minutes evaporate at a signal that turned red the instant you arrived, as if it knew.",
        "Somewhere back there, a junction quietly stole an hour of your life and never gave it back.",
        "The traffic did not move. You did not move. Time, cruelly, kept moving.",
        "An auto, a bus, and a cow formed an unbreakable trinity across the road, and you simply waited.",
        "A ten-minute stretch took fifty. Bangalore's most reliable unit of measurement is disappointment.",
        "You made excellent time right up until the exact moment you didn't. The city always collects its debt."
    )
    val bikeHealthFails = listOf(
        "That was not a pothole. A pothole has a bottom. This one had an ecosystem, and it took your front wheel as toll.",
        "A patch of diesel on wet tarmac decided today was the day. Physics handled the rest.",
        "You swerved around one crater directly into its larger, hungrier sibling.",
        "An unpainted speed-breaker launched you into a brief, unplanned career as a gymnast.",
        "Someone flung open a car door without looking. You met it at speed. The door was unharmed."
    )
    val carHealthFails = listOf(
        "You bottomed out in a flooded stretch and the engine quietly gave up on the entire concept of moving.",
        "A small scrape became a large argument became a very long delay became this.",
        "The road swallowed a wheel whole. The car sat down. So did your hopes."
    )
}

object Scenarios {
    val all: List<Scenario> = listOf(scenario1, scenario2)
}
